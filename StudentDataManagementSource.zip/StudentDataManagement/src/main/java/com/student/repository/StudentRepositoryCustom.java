package com.student.repository;

import java.util.List;

import com.student.vo.Student;

public interface StudentRepositoryCustom {

	public List<Student> deleteAndFetchRecords(Student stud);
	public List<Student> updateAndFetchRecords(Student stud);
}
