package com.student.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.student.vo.Student;

public class StudentRepositoryImpl implements StudentRepositoryCustom{

	@Autowired
    private MongoTemplate mongoTemplate;
	
	@Override
	public List<Student> deleteAndFetchRecords(Student stud) {
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(stud.getId()));
		mongoTemplate.findAndRemove(query, Student.class);
		List<Student> studentList = mongoTemplate.findAll(Student.class);
		return studentList;
	}

	@Override
	public List<Student> updateAndFetchRecords(Student stud) {
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(stud.getId()));
		Update update = new Update();
		update.set("name", stud.getName());
		update.set("age", stud.getAge());
		mongoTemplate.findAndModify(query, update, Student.class);
		List<Student> studentList = mongoTemplate.findAll(Student.class);
		return studentList;
	}

}
