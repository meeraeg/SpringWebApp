package com.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.student.repository.StudentRepository;
import com.student.vo.Student;

@Controller
public class StudentController {
	
	@Autowired
	private StudentRepository repository;

	@RequestMapping(value = "/add", method = RequestMethod.POST)
    public ResponseEntity<Student> addRecord(@RequestBody Student cntrl) {
		repository.insert(cntrl);
		return new ResponseEntity<Student>(HttpStatus.CREATED);
    }
	
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	@ResponseBody
    public List<Student> viewRecord() {
		List<Student> result = repository.findAll();
		Student.setListStudent(result);
	      return result;
    }
	
	@RequestMapping(value = "/update/{id}", method = RequestMethod.PUT)
	@ResponseBody
    public List<Student> updateRecord(@PathVariable String id, @RequestBody Student stud) {
		List<Student> result = repository.updateAndFetchRecords(stud);
		Student.setListStudent(result);
	    return result;
    }
	
	@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
	@ResponseBody
    public List<Student> deleteRecord(@PathVariable String id, @RequestBody Student cntrl) {
		List<Student> result = repository.deleteAndFetchRecords(cntrl);
		Student.setListStudent(result);
	    return result;
    }
}
