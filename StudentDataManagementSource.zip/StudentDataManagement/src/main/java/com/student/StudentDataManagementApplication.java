package com.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication(scanBasePackages={"com.student.controller"
		, "com.student.repository", "com.student.service", "com.student.vo"
})
@ComponentScan(basePackages={"com.student.controller"
		, "com.student.repository", "com.student.vo"})
@EnableMongoRepositories(basePackages = "com.student.repository")
@EnableAutoConfiguration
public class StudentDataManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentDataManagementApplication.class, args);
	}
}
